<?php
declare(strict_types=1);

namespace App\Utils;

use App\Exception\AppException;

class ConfigUtils
{
    /** @var string */
    const configPath = BASE_PATH . "/config/";

    /**
     * @param string $id
     * @return array
     * @throws AppException
     */
    public static function get(string $id): array
    {
        if (!self::has($id)) {
            throw new AppException("配置文件不存在");
        }
        return include_once self::configPath . $id . ".php";
    }

    /**
     * @param string $id
     * @return bool
     */
    public static function has(string $id): bool
    {
        $file = self::configPath . $id . ".php";
        if (!is_file($file)) {
            return false;
        }

        return true;
    }
}