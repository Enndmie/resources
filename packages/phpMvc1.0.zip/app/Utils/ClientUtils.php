<?php
declare(strict_types=1);

namespace App\Utils;

class ClientUtils
{
    /**
     * 创建支付请求
     * @return \GuzzleHttp\Client
     */
    public static function createPayRequest(): \GuzzleHttp\Client
    {
        return new \GuzzleHttp\Client(['base_uri' => 'http://103.239.247.20:9000/']);
    }

    /**
     * 获取当前域名
     * @return string
     */
    public static function getDomain(): string
    {
        $host = explode(":", (string)$_SERVER['HTTP_HOST']);
        return (string)$host[0];
    }
}