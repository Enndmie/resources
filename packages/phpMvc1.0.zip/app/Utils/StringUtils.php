<?php
declare(strict_types=1);

namespace App\Utils;

class StringUtils
{
    /**
     * 生成随机字符串
     * @param int $length
     * @return string
     */
    public static function generateRandStr(int $length = 32): string
    {
        mt_srand();
        $md5 = md5(uniqid(md5((string)time())) . mt_rand(10000, 9999999));
        return substr($md5, 0, $length);
    }

    /**
     * 生成订单号
     * @return string
     */
    public static function generateTradeNo(): string
    {
        return mt_rand(100, 999) . date("ymdHis", time()) . mt_rand(100, 999);
    }

    /**
     * 随机生成浮动金额
     * @param float $amount
     * @param int $min
     * @param int $max
     * @return float
     */
    public static function generateRandAmount(float $amount, int $min, int $max): float
    {
        mt_srand();
        return $amount + (mt_rand($min, $max) / 100);
    }


    /**
     * 随机生成整数
     * @return int
     */
    public static function generateRandNumber(): int
    {
        return mt_rand(100000, 999999);
    }
}