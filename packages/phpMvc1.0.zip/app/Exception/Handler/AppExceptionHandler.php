<?php
declare(strict_types=1);

namespace App\Exception\Handler;

use App\Exception\AppException;
use JetBrains\PhpStorm\NoReturn;
use Throwable;
use App\Exception\ViewException;
use App\Engine\ViewEngine;

class AppExceptionHandler
{
    /**
     * @param Throwable $throwable
     * @return void
     * @throws \SmartyException
     */
    #[NoReturn] public function handle(Throwable $throwable): void
    {
        switch (true) {
            case $throwable instanceof \SmartyException:
            case $throwable instanceof ViewException:
                exit((new ViewEngine())->render("error.html", ['msg' => $throwable->getMessage(), 'file' => $throwable->getFile()]));
            case $throwable instanceof AppException:
                $this->json(['code' => $throwable->getCode(), 'msg' => $throwable->getMessage()]);
        }
        $this->json(['code' => $throwable->getCode(), 'msg' => $throwable->getMessage(), 'file' => $throwable->getFile()]);
    }

    /**
     * @param array $data
     * @return void
     */
    #[NoReturn] protected function json(array $data): void
    {
        header('content-type:application/json;charset=utf-8');
        exit(json_encode($data, JSON_UNESCAPED_UNICODE));
    }
}