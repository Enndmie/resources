<?php
declare(strict_types=1);

namespace App\Controller;

abstract class Controller
{
    /**
     * 生成JSON格式
     * @param int $code
     * @param string|null $message
     * @param array|null $data
     * @return string
     */
    public function json(int $code, ?string $message = null, ?array $data = []): string
    {
        $json['code'] = $code;
        $message ? $json['msg'] = $message : null;
        $json['data'] = $data;
        return json_encode($json,JSON_UNESCAPED_UNICODE);
    }
}