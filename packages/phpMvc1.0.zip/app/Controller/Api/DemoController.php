<?php
declare(strict_types=1);

namespace App\Controller\Api;

use App\Controller\Controller;

class DemoController extends Controller
{
    public function index(): string
    {
        return $this->json(200, "这是一个演示API", ['user' => 'demo']);
    }
}