<?php
declare(strict_types=1);

namespace App\Controller;

use App\Engine\ViewEngine;

class IndexController extends Controller
{
    public function index(): string
    {
        return (new ViewEngine())->render("index.html", [
            'title' => "欢迎您",
            "user" => [
                "id" => 1,
                "user" => "admin"
            ]
        ]);
    }
}